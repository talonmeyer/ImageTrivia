<?php
   include('session.php');
?>
<html">
   
   <head>
      <title>Image Trivia! | About </title>
   </head>
   
   <body>
      <h1>About</h1> 
      <br></br>

      <h2><a href = "welcome.php">Main Menu</a></h2>
      <h2><a href = "logout.php">Sign Out</a></h2>
   </body>
   
</html>